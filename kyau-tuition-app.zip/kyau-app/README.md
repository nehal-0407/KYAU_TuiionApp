# KYAU Tuition App 🎓

A full-featured tuition management app for KYAU CSE Department built with **React + Firebase + Claude AI**.

---

## ✅ Features
- 🏠 Dashboard with stats, courses, assignments
- 📚 All 8 semesters of CSE courses (real KYAU data)
- 👨‍🏫 All 11 CSE faculty members with full profiles
- 📝 Assignment tracking (Pending / Submitted / Late / Graded)
- 💳 Payment history in ৳ BDT
- 🔔 Notifications — in-app bell + toast popups + browser push
- 🤖 KAI AI Tutor powered by Claude AI (aware of KYAU faculty & courses)
- 🔥 Firebase Auth + Firestore for chat history
- 📱 Fully responsive — works on Android & PC

---

## 🚀 Setup (Mac)

### Step 1 — Install Node.js
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node
brew install node

# Verify
node -v
npm -v
```

### Step 2 — Install dependencies
```bash
cd kyau-tuition-app
npm install
```

### Step 3 — Set up Firebase
1. Go to https://console.firebase.google.com
2. Create a new project (e.g. "kyau-tuition-app")
3. Enable **Authentication** → Sign-in method → **Anonymous** → Save
4. Enable **Firestore Database** → Start in test mode → Done
5. Project Settings → Your Apps → Web (`</>`) → Register app → Copy config

Open `src/firebaseConfig.js` and paste your config:
```js
export const firebaseConfig = {
  apiKey:            "your-actual-key",
  authDomain:        "your-project.firebaseapp.com",
  projectId:         "your-project-id",
  storageBucket:     "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId:             "your-app-id",
};
```

### Step 4 — Run the app
```bash
npm run dev
```
Open http://localhost:5173 in your browser.

---

## 📂 Project Structure
```
kyau-tuition-app/
├── src/
│   ├── App.jsx                     ← Main shell + navigation
│   ├── main.jsx                    ← Entry point
│   ├── index.css                   ← All styles
│   ├── firebase.js                 ← Firebase init
│   ├── firebaseConfig.js           ← 🔑 Add your keys here
│   ├── data/
│   │   └── kyauData.js             ← Real KYAU courses & faculty
│   ├── hooks/
│   │   └── useNotifications.jsx    ← Notification system
│   └── components/
│       ├── Dashboard.jsx
│       ├── CoursesPage.jsx
│       ├── FacultyPage.jsx
│       ├── FacultyModal.jsx
│       ├── AssignmentsPage.jsx
│       ├── PaymentsPage.jsx
│       ├── NotificationsPage.jsx
│       ├── NotifDropdown.jsx
│       ├── ToastContainer.jsx
│       └── ChatPage.jsx            ← Claude AI chatbot
├── public/
│   └── favicon.svg
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## 🛠 Tech Stack
| Layer | Technology |
|---|---|
| Framework | React 18 + Vite |
| Auth | Firebase Anonymous Auth |
| Database | Firebase Firestore |
| AI Chatbot | Claude Sonnet (Anthropic API) |
| Styling | Pure CSS (no Tailwind needed) |
| Font | Outfit (Google Fonts) |

---

## 📱 Mobile (Android)
To install on Android:
1. Build: `npm run build`
2. Host on any static server (Netlify, Vercel, etc.)
3. Open in Chrome on Android → Menu → "Add to Home Screen"

It works as a PWA on Android!

---

## ⚠️ Common Issues
| Problem | Fix |
|---|---|
| Firebase shows "Demo Mode" | Fill in `src/firebaseConfig.js` with real keys |
| AI chat not working | The Claude API works inside Claude artifacts only. For local use, set up a backend proxy |
| Blank screen | Run `npm install` then `npm run dev` again |
| Port already in use | Run `npm run dev -- --port 3000` |

---

## 📧 Contact
Department of CSE, KYAU
- Email: cse@kyau.edu.bd
- Phone: 01404461524
- HOD: F M Javed Mehedi Shamrat — shamrat.cse@kyau.edu.bd
