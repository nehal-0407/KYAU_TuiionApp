// ─────────────────────────────────────────────────────────────
//  STEP 1: Replace these values with your Firebase project keys
//  Get them from: https://console.firebase.google.com
//  Project Settings → Your Apps → Web App → Config
// ─────────────────────────────────────────────────────────────
export const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT_ID.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID",
};
