import { useState, useRef, useEffect } from 'react';
import { NotifProvider, useNotif } from './hooks/useNotifications';
import ToastContainer from './components/ToastContainer';
import NotifDropdown from './components/NotifDropdown';
import Dashboard from './components/Dashboard';
import CoursesPage from './components/CoursesPage';
import FacultyPage from './components/FacultyPage';
import AssignmentsPage from './components/AssignmentsPage';
import PaymentsPage from './components/PaymentsPage';
import NotificationsPage from './components/NotificationsPage';
import ChatPage from './components/ChatPage';

const NAV = [
  { id: 'dashboard',   icon: '🏠', label: 'Dashboard'     },
  { id: 'courses',     icon: '📚', label: 'Courses'       },
  { id: 'faculty',     icon: '👨‍🏫', label: 'Faculty'      },
  { id: 'assignments', icon: '📝', label: 'Assignments', badge: true },
  { id: 'payments',    icon: '💳', label: 'Payments'      },
  { id: 'notifs',      icon: '🔔', label: 'Notifications', notifBadge: true },
  { id: 'chat',        icon: '🤖', label: 'KAI Tutor'     },
];

const TITLES = {
  dashboard: 'Dashboard', courses: 'Courses', faculty: 'Faculty',
  assignments: 'Assignments', payments: 'Payments', notifs: 'Notifications', chat: 'KAI Tutor',
};

function Shell() {
  const [page, setPage]           = useState('dashboard');
  const [sbCollapsed, setSbCol]   = useState(false);
  const [mobileOpen, setMob]      = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [isMobile, setIsMobile]   = useState(window.innerWidth <= 640);
  const { unreadCount }           = useNotif();

  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth <= 640);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  function navigate(id) {
    setPage(id);
    if (isMobile) setMob(false);
    if (notifOpen) setNotifOpen(false);
  }

  function toggleSidebar() {
    if (isMobile) setMob(v => !v);
    else setSbCol(v => !v);
  }

  const sidebarClass = [
    'sidebar',
    !isMobile && sbCollapsed ? 'collapsed' : '',
    isMobile && mobileOpen   ? 'mobile-open' : '',
  ].filter(Boolean).join(' ');

  return (
    <>
      <ToastContainer />

      {/* Mobile overlay */}
      {isMobile && mobileOpen && (
        <div className="mobile-overlay show" onClick={() => setMob(false)} />
      )}

      {/* Notif dropdown */}
      {notifOpen && (
        <NotifDropdown
          onClose={() => setNotifOpen(false)}
          onViewAll={() => navigate('notifs')}
        />
      )}

      <div className="app-shell">
        {/* ── SIDEBAR ── */}
        <div className={sidebarClass}>
          <div className="sb-top">
            <div className="sb-logo">K</div>
            <div className="sb-brand">KYAU Tuition</div>
          </div>

          <div className="sb-nav">
            <div className="sb-section">Menu</div>
            {NAV.map(n => (
              <div
                key={n.id}
                className={`nav-item${page === n.id ? ' active' : ''}`}
                onClick={() => navigate(n.id)}
              >
                <div className="nav-icon">{n.icon}</div>
                <div className="nav-label">{n.label}</div>
                {n.badge && <span className="nav-badge">3</span>}
                {n.notifBadge && unreadCount > 0 && (
                  <span className="nav-badge">{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </div>
            ))}
          </div>

          <div className="sb-foot">
            <div className="sb-avatar">RA</div>
            <div className="sb-user-info">
              <div className="sb-name">Rafiq Ahmed</div>
              <div className="sb-role">CSE · 3rd Year</div>
            </div>
          </div>
        </div>

        {/* ── MAIN ── */}
        <div className="main">
          {/* Topbar */}
          <div className="topbar">
            <div className="tb-left">
              <div className="tb-toggle" onClick={toggleSidebar}>☰</div>
              <div className="tb-title">{TITLES[page]}</div>
            </div>
            <div className="tb-right">
              <div className="tb-chip hide-sm">
                <div className="online-dot" />
                Firebase
              </div>
              <div className="tb-chip hide-sm">KAI Live</div>
              <div className="bell-wrap" onClick={() => setNotifOpen(v => !v)}>
                <div className="bell-btn">🔔</div>
                {unreadCount > 0 && (
                  <div className="bell-badge">{unreadCount > 9 ? '9+' : unreadCount}</div>
                )}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="content">
            {page === 'dashboard'   && <Dashboard   onNavigate={navigate} />}
            {page === 'courses'     && <CoursesPage />}
            {page === 'faculty'     && <FacultyPage />}
            {page === 'assignments' && <AssignmentsPage />}
            {page === 'payments'    && <PaymentsPage />}
            {page === 'notifs'      && <NotificationsPage />}
            {page === 'chat'        && <ChatPage />}
          </div>
        </div>
      </div>
    </>
  );
}

export default function App() {
  return (
    <NotifProvider>
      <Shell />
    </NotifProvider>
  );
}
