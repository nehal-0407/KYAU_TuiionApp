import { useEffect } from 'react';

export default function FacultyModal({ faculty, onClose }) {
  useEffect(() => {
    const h = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [onClose]);

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-head">
          <div className="modal-av" style={{ background: faculty.color }}>{faculty.abbr}</div>
          <div>
            <div className="modal-name">{faculty.name}</div>
            <div className="modal-title">{faculty.title}</div>
          </div>
          <div className="modal-close" onClick={onClose}>✕</div>
        </div>
        <div className="modal-body">
          <div className="modal-row">
            <div className="modal-lbl">📧 Email</div>
            <div className="modal-val" style={{ color: 'var(--blue-600)' }}>
              <a href={`mailto:${faculty.email}`} style={{ color: 'inherit', textDecoration: 'none' }}>{faculty.email}</a>
            </div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">📞 Phone</div>
            <div className="modal-val">
              <a href={`tel:${faculty.phone}`} style={{ color: 'inherit', textDecoration: 'none' }}>{faculty.phone}</a>
            </div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">🏢 Room</div>
            <div className="modal-val">Room {faculty.room} &nbsp;|&nbsp; Intercom: {faculty.intercom}</div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">🎓 Education</div>
            <div className="modal-val">{faculty.edu}</div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">🔬 Research</div>
            <div className="modal-val">{faculty.research}</div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">📚 Courses</div>
            <div className="modal-val">{faculty.courses.join(', ')}</div>
          </div>
          <div className="modal-row">
            <div className="modal-lbl">🏛 Dept.</div>
            <div className="modal-val">Computer Science & Engineering, KYAU, Bangladesh</div>
          </div>
        </div>
      </div>
    </div>
  );
}
