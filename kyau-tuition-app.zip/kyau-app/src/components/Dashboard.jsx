import { SEMESTERS, ASSIGNMENTS } from '../data/kyauData';

const PROGS = [72, 58, 65, 80, 43, 60, 35, 90];

export default function Dashboard({ onNavigate }) {
  const currentCourses = SEMESTERS[4].courses.slice(0, 4);
  const pending = ASSIGNMENTS.filter(a => a.status === 'Pending' || a.status === 'Late');

  return (
    <div className="page fade-up">
      {/* Welcome */}
      <div className="welcome-card">
        <div className="wc-tag">Spring Semester 2026 · BSc CSE · KYAU</div>
        <div className="wc-title">Welcome back, Rafiq! 👋</div>
        <div className="wc-sub">{pending.length} pending assignments · Data Structures lab today 10:00 AM</div>
        <div className="wc-btns">
          <button className="btn btn-white" onClick={() => onNavigate('chat')}>🤖 Ask KAI Tutor</button>
          <button className="btn btn-outline" onClick={() => onNavigate('courses')}>📚 Courses</button>
          <button className="btn btn-outline" onClick={() => onNavigate('notifs')}>🔔 Notifications</button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        {[
          { icon: '📚', bg: '#dbeafe', val: '8',   lbl: 'Enrolled Courses' },
          { icon: '📝', bg: '#fef3c7', val: pending.length, lbl: 'Pending Tasks' },
          { icon: '🎥', bg: '#d1fae5', val: '1',   lbl: 'Live Today'       },
          { icon: '🏆', bg: '#fce7f3', val: '87%', lbl: 'Attendance'       },
        ].map((s, i) => (
          <div className="stat-card" key={i}>
            <div className="stat-icon" style={{ background: s.bg }}>{s.icon}</div>
            <div><div className="stat-val">{s.val}</div><div className="stat-lbl">{s.lbl}</div></div>
          </div>
        ))}
      </div>

      {/* Current courses */}
      <div className="section-hd">
        Current Semester (Y3 S1)
        <span className="section-link" onClick={() => onNavigate('courses')}>See all →</span>
      </div>
      {currentCourses.map((c, i) => (
        <div className="course-mini" key={c.code} onClick={() => onNavigate('courses')}>
          <div className="cm-icon" style={{ background: c.color }}>{c.icon}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="cm-name">{c.name}</div>
            <div className="cm-sub">{c.code} · {c.cr} Credits</div>
            <div className="cm-prog"><div className="cm-bar" style={{ width: PROGS[i] + '%' }} /></div>
          </div>
          <div className="cm-pct">{PROGS[i]}%</div>
        </div>
      ))}

      {/* Pending assignments */}
      <div className="section-hd" style={{ marginTop: 8 }}>
        Pending Assignments
        <span className="section-link" onClick={() => onNavigate('assignments')}>See all →</span>
      </div>
      <div className="card">
        {pending.slice(0, 3).map(a => (
          <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--gray-100)' }}>
            <span style={{ fontSize: 20 }}>{a.status === 'Late' ? '⚠️' : '📝'}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--gray-800)' }}>{a.name}</div>
              <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{a.course} · Due: {a.due}</div>
            </div>
            <span className={`pill ${a.status === 'Late' ? 'pill-red' : 'pill-amber'}`}>{a.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
