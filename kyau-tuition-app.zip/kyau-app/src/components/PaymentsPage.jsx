import { TRANSACTIONS, PROGRAM_INFO } from '../data/kyauData';

export default function PaymentsPage() {
  return (
    <div className="page fade-up">
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 2 }}>Payments & Fees</div>
        <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>Manage tuition fees and view transaction history</div>
      </div>

      <div className="pay-cards">
        <div className="pay-card">
          <div className="pay-icon">💰</div>
          <div className="pay-val">৳ 12,500</div>
          <div className="pay-lbl">Total Paid</div>
        </div>
        <div className="pay-card">
          <div className="pay-icon">⏳</div>
          <div className="pay-val">৳ 2,000</div>
          <div className="pay-lbl">Due Amount</div>
        </div>
        <div className="pay-card">
          <div className="pay-icon">📅</div>
          <div className="pay-val">May 1</div>
          <div className="pay-lbl">Next Due Date</div>
        </div>
      </div>

      {/* Program Fee Info */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="section-hd" style={{ marginBottom: 10 }}>Program Fee Summary</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 12.5, color: 'var(--gray-600)' }}>
          <div>Total Credits: <strong style={{ color: 'var(--gray-800)' }}>{PROGRAM_INFO.totalCredits}</strong></div>
          <div>Duration: <strong style={{ color: 'var(--gray-800)' }}>{PROGRAM_INFO.duration}</strong></div>
          <div>Semesters: <strong style={{ color: 'var(--gray-800)' }}>{PROGRAM_INFO.semesters}</strong></div>
          <div>Admission Fee: <strong style={{ color: 'var(--gray-800)' }}>৳ {PROGRAM_INFO.admissionFee.toLocaleString()}</strong></div>
          <div style={{ gridColumn: '1/-1' }}>
            Total Program Fee: <strong style={{ color: 'var(--blue-600)', fontSize: 14 }}>৳ {PROGRAM_INFO.totalFee.toLocaleString()}</strong>
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <button className="btn btn-primary" style={{ marginRight: 8 }}>💳 Pay via bKash</button>
          <button className="btn" style={{ background: 'var(--gray-100)', color: 'var(--gray-700)' }}>📄 Download Receipt</button>
        </div>
      </div>

      {/* Transactions */}
      <div className="section-hd" style={{ marginBottom: 10 }}>Transaction History</div>
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Description</th>
              <th className="hide-mobile">Date</th>
              <th className="hide-mobile">Method</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {TRANSACTIONS.map((t, i) => (
              <tr key={i}>
                <td>
                  <div className="cell-name">{t.desc}</div>
                  <div className="cell-sub">{t.method} · {t.date}</div>
                </td>
                <td className="hide-mobile">{t.date}</td>
                <td className="hide-mobile">{t.method}</td>
                <td style={{ fontWeight: 700, color: t.type === 'in' ? 'var(--green)' : 'var(--red)' }}>
                  {t.type === 'in' ? '+' : '-'}৳ {Math.abs(t.amount).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
