import { ASSIGNMENTS } from '../data/kyauData';

const STATUS_CLASS = { Pending: 'pill-amber', Submitted: 'pill-green', Late: 'pill-red', Graded: 'pill-blue' };

export default function AssignmentsPage() {
  return (
    <div className="page fade-up">
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 2 }}>Assignments</div>
        <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>Track, submit, and view your graded work</div>
      </div>

      {/* Summary pills */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        {['Pending','Late','Submitted','Graded'].map(s => {
          const count = ASSIGNMENTS.filter(a => a.status === s).length;
          return <span key={s} className={`pill ${STATUS_CLASS[s]}`} style={{ fontSize: 12, padding: '4px 12px' }}>{s}: {count}</span>;
        })}
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Assignment</th>
              <th className="hide-mobile">Teacher</th>
              <th className="hide-mobile">Due Date</th>
              <th>Status</th>
              <th className="hide-mobile">Action</th>
            </tr>
          </thead>
          <tbody>
            {ASSIGNMENTS.map(a => (
              <tr key={a.id}>
                <td>
                  <div className="cell-name">{a.name}</div>
                  <div className="cell-sub">{a.course} · {a.due}</div>
                </td>
                <td className="hide-mobile">{a.teacher}</td>
                <td className="hide-mobile">{a.due}</td>
                <td>
                  <span className={`pill ${STATUS_CLASS[a.status]}`}>
                    {a.status === 'Graded' ? `${a.status} — ${a.grade}` : a.status}
                  </span>
                </td>
                <td className="hide-mobile">
                  <button
                    className="btn btn-primary"
                    style={{ fontSize: 11, padding: '4px 12px' }}
                    disabled={a.status === 'Graded'}
                  >
                    {a.status === 'Submitted' ? 'View' : a.status === 'Graded' ? '✓ Done' : 'Submit'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
