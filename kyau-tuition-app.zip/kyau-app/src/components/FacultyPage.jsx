import { useState } from 'react';
import { FACULTY, DEPT_CONTACT } from '../data/kyauData';
import FacultyModal from './FacultyModal';

export default function FacultyPage() {
  const [selected, setSelected] = useState(null);

  return (
    <div className="page fade-up">
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 2 }}>CSE Faculty</div>
        <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>Dept. of Computer Science & Engineering · KYAU · {FACULTY.length} members · Tap a card for full profile</div>
      </div>

      <div className="faculty-grid">
        {FACULTY.map(f => (
          <div className="faculty-card" key={f.id} onClick={() => setSelected(f)}>
            <div className="fc-avatar" style={{ background: f.color }}>{f.abbr}</div>
            <div className="fc-name">{f.name}</div>
            <div className="fc-title">{f.title}</div>
            <div className="fc-email">{f.email}</div>
            <div className="fc-phone">📞 {f.phone}</div>
          </div>
        ))}
      </div>

      {/* Dept Contact */}
      <div className="card" style={{ marginTop: 16 }}>
        <div className="section-hd" style={{ marginBottom: 10 }}>Department Contact</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 12, color: 'var(--gray-600)' }}>
          <div>📞 {DEPT_CONTACT.mobile}</div>
          <div>☎️ {DEPT_CONTACT.tel}</div>
          <div>📧 {DEPT_CONTACT.email}</div>
          <div>📟 Intercom: {DEPT_CONTACT.intercom}</div>
          <div>🏢 Room: {DEPT_CONTACT.room}</div>
          <div>🏛 {DEPT_CONTACT.building}</div>
        </div>
      </div>

      {selected && <FacultyModal faculty={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
