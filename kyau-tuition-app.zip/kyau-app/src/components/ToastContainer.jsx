import { useNotif } from '../hooks/useNotifications';

export default function ToastContainer() {
  const { toasts, removeToast } = useNotif();
  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.toastId} className={`toast${t.leaving ? ' out' : ''}`}>
          <div className={`bar ${t.type}`} />
          <div className="toast-icon">{t.icon}</div>
          <div className="toast-body">
            <div className="toast-title">{t.title}</div>
            <div className="toast-msg">{t.msg.length > 65 ? t.msg.slice(0, 65) + '…' : t.msg}</div>
            <div className="toast-time">{t.time}</div>
          </div>
          <div className="toast-close" onClick={() => removeToast(t.toastId)}>✕</div>
        </div>
      ))}
    </div>
  );
}
