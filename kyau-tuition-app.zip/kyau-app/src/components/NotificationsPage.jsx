import { useNotif } from '../hooks/useNotifications';

export default function NotificationsPage() {
  const { notifications, markRead, markAllRead, addNotification } = useNotif();

  const fireTest = () => {
    const options = [
      { type: 'assign', icon: '📝', bg: '#fef3c7', title: 'Reminder: Assignment Due', msg: 'OOP-II Mini Project due in 24 hours — Submit before midnight!' },
      { type: 'live',   icon: '🎥', bg: '#d1fae5', title: 'Live Class in 10 Minutes', msg: 'CSE 2203 Algorithm Analysis class starts soon — Join now' },
      { type: 'msg',    icon: '💬', bg: '#dbeafe', title: 'New Message from Teacher',  msg: 'Md. Abu Raihan replied to your question about the lab report' },
      { type: 'fee',    icon: '💳', bg: '#fee2e2', title: 'Payment Reminder',          msg: '৳2,000 due in 5 days. Pay via bKash or Card to avoid late fees.' },
      { type: 'grade',  icon: '🏆', bg: '#ede9fe', title: 'New Grade Available',       msg: 'CSE 2107 Digital Logic assignment has been graded — Check now!' },
    ];
    addNotification(options[Math.floor(Math.random() * options.length)]);
  };

  return (
    <div className="page fade-up">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 2 }}>Notifications</div>
          <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>{notifications.filter(n => n.unread).length} unread of {notifications.length} total</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" style={{ background: 'var(--gray-100)', color: 'var(--gray-700)', fontSize: 12 }} onClick={markAllRead}>
            ✓ Mark all read
          </button>
          <button className="btn btn-primary" style={{ fontSize: 12 }} onClick={fireTest}>
            🔔 Test Notify
          </button>
        </div>
      </div>

      {notifications.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 48, color: 'var(--gray-400)' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🎉</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>All caught up!</div>
          <div style={{ fontSize: 12, marginTop: 4 }}>No notifications yet</div>
        </div>
      ) : (
        notifications.map(n => (
          <div key={n.id} className={`notif-view-item${n.unread ? ' unread' : ''}`} onClick={() => markRead(n.id)}>
            <div className={`bar ${n.type}`} />
            <div className="nv-icon" style={{ background: n.bg }}>{n.icon}</div>
            <div className="nv-body">
              <div className="nv-title">{n.title}</div>
              <div className="nv-text">{n.msg}</div>
              <div className="nv-time">{n.time}</div>
            </div>
            {n.unread && <div className="nv-dot" />}
          </div>
        ))
      )}
    </div>
  );
}
