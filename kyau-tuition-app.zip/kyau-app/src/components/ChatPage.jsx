import { useState, useRef, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot } from 'firebase/firestore';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { FACULTY, SEMESTERS } from '../data/kyauData';

const SUBJECTS = ['General 🤖', 'Programming 💻', 'Data Structures 🔗', 'Algorithms ⚙️', 'Databases 🗄️', 'Networks 🌐', 'OS 🖥️', 'AI 🤖', 'Maths 📐', 'Web 🌐'];
const PROMPTS = [
  'What is a linked list?',
  'Explain Big-O notation',
  'How does SQL JOIN work?',
  'What is process scheduling?',
  'Explain OOP concepts',
  'How does TCP/IP work?',
  'Who is the HOD of CSE at KYAU?',
];

const facultyList = FACULTY.map(f => `${f.name} (${f.title})`).join(', ');
const courseList  = SEMESTERS.flatMap(s => s.courses).map(c => `${c.code} ${c.name}`).slice(0, 20).join(', ');

function fmt(text) {
  return text
    .replace(/```([\s\S]*?)```/g, '<pre>$1</pre>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br>');
}

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput]       = useState('');
  const [subject, setSubject]   = useState('General 🤖');
  const [loading, setLoading]   = useState(false);
  const [userId, setUserId]     = useState(null);
  const [fbStatus, setFbStatus] = useState('connecting');
  const endRef   = useRef();
  const taRef    = useRef();

  // Firebase auth
  useEffect(() => {
    signInAnonymously(auth)
      .then(() => setFbStatus('connected'))
      .catch(() => setFbStatus('demo'));

    onAuthStateChanged(auth, user => {
      if (user) setUserId(user.uid);
    });
  }, []);

  // Load chat history from Firestore
  useEffect(() => {
    if (!userId || fbStatus !== 'connected') return;
    const q = query(
      collection(db, `chats/${userId}/messages`),
      orderBy('timestamp', 'asc')
    );
    const unsub = onSnapshot(q, snap => {
      const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (msgs.length > 0) setMessages(msgs);
    });
    return unsub;
  }, [userId, fbStatus]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function saveToFirestore(role, content) {
    if (!userId || fbStatus !== 'connected') return;
    try {
      await addDoc(collection(db, `chats/${userId}/messages`), {
        role, content, subject, timestamp: serverTimestamp(),
      });
    } catch (e) { console.warn('Firestore write failed:', e); }
  }

  async function callClaude(history) {
    const system = `You are KAI — the official AI tutor for KYAU (Khwaja Yunus Ali University) Tuition App, CSE Department, Enayetpur, Sirajganj, Bangladesh.

Real Faculty: ${facultyList}.
HOD: F M Javed Mehedi Shamrat (Asst. Professor & Head). Email: shamrat.cse@kyau.edu.bd. Phone: 01912639604.
Program Coordinator: Miss. Rokeya Akter.
Department contact: cse@kyau.edu.bd, 01404461524, Room 309-(A).
Sample courses: ${courseList}.
Program: BSc CSE, 4 years, 8 semesters, 150 credits. Total fee: ৳5,02,500. Admission fee: ৳12,000.
Current subject focus: ${subject}.

Your role:
- Help students understand CSE subjects: Programming, Data Structures, Algorithms, Databases, Networks, OS, AI, Mathematics, Web Engineering.
- Give clear, step-by-step explanations with examples.
- Be warm and encouraging — like a friendly Bangladeshi university tutor.
- If asked about faculty or the app, answer using the real data above.
- Keep responses concise (under 250 words) unless more detail is specifically needed.
- Use bullet points, numbered lists, or code blocks when helpful.`;

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system,
        messages: history,
      }),
    });
    const data = await res.json();
    return data?.content?.[0]?.text || 'Sorry, I could not get a response. Please try again.';
  }

  async function send(text) {
    const content = (text || input).trim();
    if (!content || loading) return;
    setInput('');
    if (taRef.current) taRef.current.style.height = 'auto';

    const userMsg = { role: 'user', content, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) };
    setMessages(prev => [...prev, userMsg]);
    saveToFirestore('user', content);
    setLoading(true);

    try {
      const history = [...messages, userMsg]
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .slice(-20)
        .map(m => ({ role: m.role, content: m.content }));
      const reply = await callClaude(history);
      const aiMsg = { role: 'assistant', content: reply, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) };
      setMessages(prev => [...prev, aiMsg]);
      saveToFirestore('assistant', reply);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: '⚠️ Connection error. Please check your internet and try again.', time: '' }]);
    } finally {
      setLoading(false);
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  }

  function autoResize(e) {
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 110) + 'px';
  }

  return (
    <div className="chat-page">
      {/* Subject bar */}
      <div className="chat-subbar">
        {SUBJECTS.map(s => (
          <div key={s} className={`subchip${subject === s ? ' active' : ''}`} onClick={() => setSubject(s)}>{s}</div>
        ))}
      </div>

      {/* Messages */}
      <div className="chat-messages">
        {messages.length === 0 ? (
          <div className="chat-intro">
            <div className="kai-icon">🤖</div>
            <div className="kai-title">KAI — Your AI Tutor</div>
            <div className="kai-sub">
              Powered by Claude AI + Firebase. Ask anything about KYAU CSE courses, faculty, or any subject!
            </div>
            <div className="prompt-chips">
              {PROMPTS.map(p => (
                <div key={p} className="prompt-chip" onClick={() => send(p)}>{p}</div>
              ))}
            </div>
          </div>
        ) : (
          messages.map((m, i) => (
            <div key={m.id || i} className={`msg-row${m.role === 'user' ? ' user' : ''}`}>
              <div className={`msg-avatar ${m.role === 'user' ? 'user' : 'ai'}`}>
                {m.role === 'user' ? 'RA' : '🤖'}
              </div>
              <div className="msg-body">
                <div
                  className={`bubble ${m.role === 'user' ? 'user' : 'ai'}`}
                  dangerouslySetInnerHTML={{ __html: fmt(m.content) }}
                />
                {m.time && <div className="msg-time">{m.time}</div>}
              </div>
            </div>
          ))
        )}

        {loading && (
          <div className="msg-row">
            <div className="msg-avatar ai">🤖</div>
            <div className="typing-bubble">
              <div className="typing-dot" />
              <div className="typing-dot" />
              <div className="typing-dot" />
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input */}
      <div className="chat-input-bar">
        <div className="chat-input-wrap">
          <textarea
            ref={taRef}
            className="chat-textarea"
            placeholder={`Ask KAI about ${subject.split(' ')[0]}…`}
            value={input}
            onChange={e => setInput(e.target.value)}
            onInput={autoResize}
            onKeyDown={onKeyDown}
            rows={1}
          />
        </div>
        <button className="send-btn" onClick={() => send()} disabled={!input.trim() || loading}>
          {loading ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : '↑'}
        </button>
      </div>
      <div className="fb-note">
        🔥 Firebase {fbStatus === 'connected' ? `Connected · Saving history · User ${userId?.slice(0, 8)}…` : 'Demo Mode — Add your Firebase keys to enable history'}
        {messages.length > 0 && (
          <span
            style={{ marginLeft: 12, color: 'var(--blue-500)', cursor: 'pointer' }}
            onClick={() => setMessages([])}
          >
            Clear chat
          </span>
        )}
      </div>
    </div>
  );
}
