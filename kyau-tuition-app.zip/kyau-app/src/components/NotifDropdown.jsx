import { useEffect, useRef } from 'react';
import { useNotif } from '../hooks/useNotifications';

export default function NotifDropdown({ onClose, onViewAll }) {
  const { notifications, markRead, markAllRead } = useNotif();
  const ref = useRef();

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onClose]);

  return (
    <div className="notif-dropdown" ref={ref}>
      <div className="nd-head">
        <div className="nd-title">🔔 Notifications</div>
        <div className="nd-mark" onClick={markAllRead}>Mark all read</div>
      </div>
      <div className="nd-list">
        {notifications.length === 0
          ? <div className="nd-empty">🎉 All caught up!</div>
          : notifications.slice(0, 6).map(n => (
            <div key={n.id} className={`notif-item${n.unread ? ' unread' : ''}`} onClick={() => markRead(n.id)}>
              <div className={`bar ${n.type}`} />
              <div className="ni-icon" style={{ background: n.bg }}>{n.icon}</div>
              <div className="ni-body">
                <div className="ni-title">{n.title}</div>
                <div className="ni-text">{n.msg}</div>
                <div className="ni-time">{n.time}</div>
              </div>
              {n.unread && <div className="ni-dot" />}
            </div>
          ))}
      </div>
      <div className="nd-footer" onClick={() => { onViewAll(); onClose(); }}>
        View all notifications →
      </div>
    </div>
  );
}
