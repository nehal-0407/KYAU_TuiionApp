import { useState } from 'react';
import { SEMESTERS } from '../data/kyauData';

export default function CoursesPage() {
  const [active, setActive] = useState(0);
  const sem = SEMESTERS[active];

  return (
    <div className="page fade-up">
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 2 }}>BSc CSE Courses</div>
        <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>150 Credits · 4 Years · 8 Semesters · {sem.courses.reduce((s, c) => s + c.cr, 0)} credits this semester</div>
      </div>

      <div className="sem-tabs">
        {SEMESTERS.map((s, i) => (
          <div key={i} className={`sem-tab${active === i ? ' active' : ''}`} onClick={() => setActive(i)}>
            {s.label}
          </div>
        ))}
      </div>

      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--gray-600)', marginBottom: 12 }}>
        📅 {sem.full} &nbsp;·&nbsp; {sem.courses.length} courses &nbsp;·&nbsp; {sem.courses.reduce((s, c) => s + c.cr, 0)} total credits
      </div>

      <div className="courses-grid">
        {sem.courses.map(c => (
          <div className="course-card" key={c.code + c.name}>
            <div className="cc-banner" style={{ background: c.color }}>{c.icon}</div>
            <div className="cc-body">
              <div className="cc-code">{c.code}</div>
              <div className="cc-name">{c.name}</div>
              <div style={{ marginTop: 5 }}>
                <span className={`pill ${c.lab ? 'pill-green' : 'pill-blue'}`}>
                  {c.lab ? '🔬 Lab' : '📖 Theory'}
                </span>
              </div>
              <div className="cc-foot">
                <div className="cc-cr">{c.cr} Credit{c.cr > 1 ? 's' : ''}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
