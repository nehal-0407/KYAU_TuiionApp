import { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import { NOTIFICATION_TEMPLATES } from '../data/kyauData';

const NotifContext = createContext(null);

export function NotifProvider({ children }) {
  const [notifications, setNotifications] = useState(
    NOTIFICATION_TEMPLATES.map((n, i) => ({ ...n, id: i, unread: i < 5 }))
  );
  const [toasts, setToasts] = useState([]);
  const toastId = useRef(100);

  const unreadCount = notifications.filter(n => n.unread).length;

  const addNotification = useCallback((notif) => {
    const id = Date.now();
    const n = { ...notif, id, unread: true, time: 'Just now' };
    setNotifications(prev => [n, ...prev]);

    // Toast
    const tid = toastId.current++;
    setToasts(prev => [...prev, { ...n, toastId: tid }]);
    setTimeout(() => {
      setToasts(prev => prev.map(t => t.toastId === tid ? { ...t, leaving: true } : t));
      setTimeout(() => setToasts(prev => prev.filter(t => t.toastId !== tid)), 350);
    }, 5000);

    // Browser push
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('KYAU Tuition — ' + notif.title, { body: notif.msg });
    }
  }, []);

  const markRead = useCallback((id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, unread: false } : n));
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  }, []);

  const removeToast = useCallback((toastId) => {
    setToasts(prev => prev.map(t => t.toastId === toastId ? { ...t, leaving: true } : t));
    setTimeout(() => setToasts(prev => prev.filter(t => t.toastId !== toastId)), 350);
  }, []);

  // Request push permission on mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  // Auto-fire demo notifications
  useEffect(() => {
    const demos = [
      { delay: 5000,  type: 'live',  icon: '🎥', bg: '#d1fae5', title: 'Live Class Starting Soon', msg: 'CSE 3103 Operating System class starts in 10 minutes — Room 301' },
      { delay: 14000, type: 'msg',   icon: '💬', bg: '#dbeafe', title: 'Message from HOD',          msg: 'F M Javed Mehedi Shamrat: Updated exam schedule has been posted' },
      { delay: 25000, type: 'grade', icon: '🏆', bg: '#ede9fe', title: 'Grade Published!',          msg: 'Your CSE 3101 DBMS assignment has been graded — You scored A+' },
    ];
    const timers = demos.map(d => setTimeout(() => addNotification(d), d.delay));
    return () => timers.forEach(clearTimeout);
  }, [addNotification]);

  return (
    <NotifContext.Provider value={{ notifications, unreadCount, addNotification, markRead, markAllRead, toasts, removeToast }}>
      {children}
    </NotifContext.Provider>
  );
}

export const useNotif = () => useContext(NotifContext);
